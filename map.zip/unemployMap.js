// 실업자 수 (2025.04 기준)
const unemployment = {
  "서울특별시": 211, "부산광역시": 38, "대구광역시": 47,
  "인천광역시": 57, "광주광역시": 28, "대전광역시": 23,
  "울산광역시": 14, "세종특별자치시": 4, "경기도": 226,
  "강원도": 17, "충청북도": 20, "충청남도": 39,
  "전라북도": 27, "전라남도": 21, "경상북도": 40,
  "경상남도": 34, "제주도": 10
};

// 영어 이름 → 한글 이름 매핑
const titleToKorean = {
  "Seoul": "서울특별시",
  "Busan": "부산광역시",
  "Daegu": "대구광역시",
  "Incheon": "인천광역시",
  "Gwangju": "광주광역시",
  "Daejeon": "대전광역시",
  "Ulsan": "울산광역시",
  "Sejong": "세종특별자치시",
  "Gyeonggi": "경기도",
  "Gangwon": "강원도",
  "North Chungcheong": "충청북도",
  "South Chungcheong": "충청남도",
  "North Jeolla": "전라북도",
  "South Jeolla": "전라남도",
  "North Gyeongsang": "경상북도",
  "South Gyeongsang": "경상남도",
  "Jeju": "제주도"
};

// 각 시도 중심 좌표 (지도 맞게 수동 설정)
const regionCenters = {
  "서울특별시": [126.9780, 37.5665],
  "부산광역시": [129.0756, 35.1796],
  "대구광역시": [128.6014, 35.8714],
  "인천광역시": [126.7052, 37.4563],
  "광주광역시": [126.8514, 35.1595],
  "대전광역시": [127.3845, 36.3504],
  "울산광역시": [129.3114, 35.5384],
  "세종특별자치시": [127.2890, 36.4800],
  "경기도": [127.5183, 37.4138],
  "강원도": [128.3115, 37.8228],
  "충청북도": [127.4914, 36.6357],
  "충청남도": [126.8044, 36.5184],
  "전라북도": [127.1088, 35.8200],
  "전라남도": [126.4630, 34.8161],
  "경상북도": [128.5056, 36.5755],
  "경상남도": [128.6919, 35.4606],
  "제주도": [126.5312, 33.4996]
};

const width = 800;
const height = 1000;

const color = d3.scaleSequentialLog()
  .domain([1, d3.max(Object.values(unemployment))])
  .interpolator(d3.interpolateBlues);

const radius = d3.scaleSqrt()
  .domain([0, d3.max(Object.values(unemployment))])
  .range([0, 40]); // 거품 최대 크기

const projection = d3.geoMercator()
  .center([127.5, 36])
  .scale(5000)
  .translate([width / 2, height / 2]);

const path = d3.geoPath().projection(projection);
const tooltip = d3.select(".tooltip");

d3.xml("south-korea.svg").then(data => {
  const svgNode = data.documentElement;
  const container = d3.select("#map").append("svg")
    .attr("width", width)
    .attr("height", height);

  container.node().appendChild(svgNode);

  const regions = d3.select(svgNode).selectAll("path");

  regions.each(function () {
    const pathEl = d3.select(this);
    const engName = pathEl.attr("title");
    const korName = titleToKorean[engName];

    const val = unemployment[korName];
    pathEl.attr("fill", val ? color(val) : "#ccc");

    pathEl.on("mouseover", (event) => {
      tooltip.style("opacity", 1)
        .html(`<strong>${korName}</strong><br>실업자 수: ${val || "없음"}`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 20) + "px");
    }).on("mouseout", () => {
      tooltip.style("opacity", 0);
    });
  });

  // 거품 추가

});
